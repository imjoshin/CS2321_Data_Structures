public class EndOfListException extends Exception {
   private static final long serialVersionUID = 1L;
}